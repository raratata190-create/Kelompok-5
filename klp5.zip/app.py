from flask import Flask, render_template, jsonify
import random

app = Flask(__name__)

# =========================
# REALTIME DATA
# =========================
sensor_data = {
    "soil": 0,
    "water": 0,
    "distance": 0
}

# =========================
# DUMMY HISTORY 24 JAM
# =========================
history_data = []

for i in range(24):

    jam = f"{i:02d}:00"

    history_data.append({
        "time": jam,
        "avg_soil": random.randint(40, 90),
        "avg_water": random.randint(900, 1800),
        "avg_distance": round(random.uniform(5, 20), 1)
    })

# =========================
# DASHBOARD
# =========================
@app.route('/')
def home():
    return render_template('dashboard.html')

# =========================
# API REALTIME
# =========================
@app.route('/api/live')
def live_data():

    sensor_data['soil'] = random.randint(40, 90)
    sensor_data['water'] = random.randint(900, 1800)
    sensor_data['distance'] = round(random.uniform(5, 20), 1)

    return jsonify(sensor_data)

# =========================
# API HISTORY
# =========================
@app.route('/api/history')
def history():
    return jsonify(history_data)

# =========================
# RUN
# =========================
if __name__ == "__main__":
    app.run(host='0.0.0.0', port=8080, debug=True)